package my.id.phyton06.markuscell.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import my.id.phyton06.markuscell.R
import my.id.phyton06.

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       inputEmail.
    }



}